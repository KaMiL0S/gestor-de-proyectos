<?php
include '../model/crear_empresas.php';

$apiEmp = new Empresas();
$action = $_POST['action'];

if (isset($action)) {
    switch ($action){
        case 'crearEmpresa':
            $post = [];
        	array_push($post, $_POST['nombre']);
            array_push($post, $_POST['nit']);
            array_push($post, $_POST['telefono']);
            array_push($post, $_POST['direccion']);
            array_push($post, $_POST['email']);
            $result = $apiEmp->insertEmpresa($post);
            echo json_encode($result);
            break;
        default:
            $usuarios->return->bool = false;
            $usuarios->return->msg = 'Acción No Encontrada';
            break;
    } 
}

?>