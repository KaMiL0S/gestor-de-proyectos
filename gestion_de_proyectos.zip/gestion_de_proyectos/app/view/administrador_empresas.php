<?php if($tipo_usuario == 1) { ?>
<button type="button" id="crear_empresa" class="btn btn-success">Crear empresa</button><br>
<div class="card mb-4" id="cargue_empresas">
    <div class="card-header"><i class="fas fa-table mr-1"></i>Administrador de empresas</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>usuario</th>
                        <th>password</th>
                        <th>nombre</th>
                        <th>eliminar</th>
                        <th>modificar</th>
					</tr>
				</thead>
                <tbody id="tabla_usuarios">
                    <?php include 'model/empresas.php'; ?>
                </tbody>
			</table>
		</div>
	</div>
</div>
<div class="container" id="crear_empresa">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <div class="card shadow-lg border-0 rounded-lg mt-5" id="Registro">
                <div class="card-header"><h3 class="text-center font-weight-light my-4">Crear Cuenta</h3></div>
                <div class="card-body">
                    <form method="post">
                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-group"><label class="small mb-1" for="inputNombre_e">NOMBRE</label><input class="form-control py-4 registrar_empresa" id="inputNombre_e" type="text" placeholder="Introduzca el Nombre" /></div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"><label class="small mb-1" for="inputNit_e">NIT</label><input class="form-control py-4 registrar_empresa" id="inputNit_e" type="text" placeholder="Introduzca el Nit" /></div>
                            </div>
                        </div>
                        <div class="form-group"><label class="small mb-1" for="inputTelefono_e">TELEFONO</label><input class="form-control py-4 registrar_empresa" id="inputTelefono_e" type="number" placeholder="Introduzca el Telefono" /></div>
                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="form-group"><label class="small mb-1" for="inputDireccion_e">DIRECCIÓN</label><input class="form-control py-4" id="inputDireccion_e" type="text" placeholder="Introduzca la direccion" /></div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group"><label class="small mb-1" for="inputemail_e">CORREO ELECTRONICO</label><input class="form-control py-4" id="inputemail_e" type="email" placeholder="Introduzca el Email" /></div>
                            </div>
                        </div>
                        <div class="form-group mt-4 mb-0"><a class="btn btn-primary btn-block" id="btn_empresa" role="button" style="color: white;">Crear Empresa</a></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>