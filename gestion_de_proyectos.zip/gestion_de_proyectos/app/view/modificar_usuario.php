<div class="container">
	<div class="row">
		<input type="hidden" class="form-control" name="id_mod" id="id_mod">
		<div class="col-4">
			<input type="text" class="form-control" name="usuario_mod" id="usuario_mod" readonly>
		</div>
		<div class="col-4">
			<input type="text" class="form-control" name="password_mod" id="password_mod">
		</div>
		<div class="col-4">
			<input type="text" class="form-control" name="nombre_mod" id="nombre_mod">
		</div>
	</div><br>
	<div class="row">
		<div class="col-4">
			<button type="button" class="btn btn-success" id="btn_Mod">Modificar</button>
		</div>
	</div>
</div>