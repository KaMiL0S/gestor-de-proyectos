<?php if($tipo_usuario == 1) { ?>
<div class="card mb-4">
    <div class="card-header"><i class="fas fa-table mr-1"></i>Administrar Usuarios</div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>usuario</th>
                        <th>password</th>
                        <th>nombre</th>
                        <th>eliminar</th>
                        <th>modificar</th>
					</tr>
				</thead>
                <tbody id="tabla_usuarios">
                    <?php include 'model/tabla_eliminar.php'; ?>
                </tbody>
			</table>
		</div>
	</div>
</div>
<?php } ?>