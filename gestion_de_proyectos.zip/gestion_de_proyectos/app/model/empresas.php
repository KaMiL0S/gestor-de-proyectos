<?php
include '../config/conexion.php';
$conteo = 0;
$sql = "SELECT id, nombre, nit, telefono, direccion, email FROM empresas WHERE estado='1'";
    $resultado = $mysqli->query($sql);
    while($row = $resultado->fetch_array(MYSQLI_ASSOC)){
        $conteo++;
        echo "<tr><td class='id_".$conteo."'>" . 
            $row["id"] . "</td>";
        echo "<td class='usuario_".$conteo."'>" . 
            $row["nombre"] . "</td>";
        echo "<td class='pass_".$conteo."'>" . 
            $row["nit"] . "</td>";
        echo "<td class='nom_".$conteo."'>" . 
            $row["telefono"] . "</td>";
        echo "<td class='nom_".$conteo."'>" . 
            $row["direccion"] . "</td>";
        echo "<td class='nom_".$conteo."'>" . 
            $row["email"] . "</td>";
        echo "<td><button class='button btn btn-primary eliminar_usu' id='elimi".$conteo."'>Eliminar</button></td>";
        echo "<td><button class='button btn btn-success modif_usu' id='modif".$conteo."'>Modificar</button></td></tr>"; 
    };

?>