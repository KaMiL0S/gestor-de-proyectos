<?php
require_once "../../config/conexion.php";
session_start();

class Empresas
{
    public function insertEmpresa($data){

    	global $mysqli;
    	$NOMBRE = $data[0];
    	$NIT = $data[1];
    	$TELEFONO = $data[2];
    	$DIRECCION = $data[3];
    	$EMAIL = $data[4];

    	$sql = "INSERT INTO empresas (nombre, nit, telefono, direccion, email, estado)VALUES('$NOMBRE','$NIT',$TELEFONO,'$DIRECCION','$EMAIL','1')";
    	$resultado = $mysqli->query($sql);

    	if ($resultado) {
    		return true;
    	}else{
    		return false;
    	}
    }
}


?>